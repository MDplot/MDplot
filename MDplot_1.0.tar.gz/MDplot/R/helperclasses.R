# definition of class: "MDplot_argument"
setClass( "MDplot_argument", representation = representation( key = "character", value = "character" ), sealed = TRUE )

#########